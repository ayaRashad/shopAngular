import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  public flag = true
 

  commonApiUrl = 'http://localhost:5000'
  constructor(private _http:HttpClient) { }

  register(userData:any) : Observable<any>{
    return this._http.post(`${this.commonApiUrl}/auth/register`,userData)

  }
}
