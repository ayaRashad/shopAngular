import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RegisterComponent } from './pages/user/register/register.component';
import { LoginuserComponent } from './pages/user/loginuser/loginuser.component';
import { myProductComponent } from './pages/product/myProduct/myProduct.component';

import { Err404Component } from './pages/err404/err404.component';

const routes: Routes = [
  {path:"register",component:RegisterComponent},
  {path:"login",component:LoginuserComponent},
  {path:"product", component:myProductComponent},

  //{path:"", component:AllusersComponent},
  //{path:"login", component:LoginComponent},
  //{path:"user", children:[
   // {path:"", component:ProfileComponent},
    //{path:"show/:id", component:SingleuserComponent},
   // {path:"edit/:id", component:UsercardComponent},
   // {path:"delete/:id", component:RegisterComponent}
  //]},
  {path:"**", component:Err404Component}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
