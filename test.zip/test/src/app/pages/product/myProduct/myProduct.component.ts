import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myProduct',
  templateUrl: './myProduct.component.html',
  styleUrls: ['./myProduct.component.css']
})
export class myProductComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
